LICENSE
=======

Apache 2.0 (http://www.apache.org/licenses/LICENSE-2.0.txt)
